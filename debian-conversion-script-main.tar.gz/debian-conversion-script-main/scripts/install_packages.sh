#!/bin/bash

set -euo pipefail

source "$SCRIPT_DIR/scripts/handle_error.sh"

install_packages() {
    if [ $# -eq 0 ]; then
        handle_error "No packages specified for installation."
    fi
    run "Installing packages: $*" apt install -y "$@"
}
