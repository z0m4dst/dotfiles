#!/bin/bash

set -euo pipefail

source "$SCRIPT_DIR/scripts/install_packages.sh"

security() {
    local security_packages
    mapfile -t security_packages < "$SCRIPT_DIR/config/packages/security.txt"

    install_packages "${security_packages[@]}"
    echo "[!] Security Edition packages installation completed successfully."
}
