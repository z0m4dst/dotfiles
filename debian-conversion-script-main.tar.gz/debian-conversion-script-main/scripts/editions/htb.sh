#!/bin/bash

set -euo pipefail

source "$SCRIPT_DIR/scripts/install_packages.sh"

htb() {
    local htb_packages
    mapfile -t htb_packages < "$SCRIPT_DIR/config/packages/htb.txt"

    install_packages "${htb_packages[@]}"
    echo "[!] Hack The Box Edition packages installation completed successfully."
}
