#!/bin/bash

set -euo pipefail

source "$SCRIPT_DIR/scripts/run.sh"
source "$SCRIPT_DIR/scripts/install_packages.sh"

core() {
    local core_packages
    mapfile -t core_packages < "$SCRIPT_DIR/config/packages/core.txt"

    # Install prerequisites available from Debian repos
    run "Updating package lists" apt update
    run "Installing prerequisites" apt install -y bash wget gnupg

    # Set up Parrot APT repositories
    echo "Backing up Debian sources"
    mkdir -p /etc/apt/sources.bak.d
    cp /etc/apt/sources.list /etc/apt/sources.bak.d/ 2>/dev/null || true
    cp -a /etc/apt/sources.list.d /etc/apt/sources.bak.d/ 2>/dev/null || true
    
    run "Downloading parrot-archive-keyring" wget -O /tmp/parrot-archive-keyring.deb https://deb.parrot.sh/parrot/pool/main/p/parrot-archive-keyring/parrot-archive-keyring_2024.12_all.deb
    run "Installing parrot-archive-keyring" apt install -y /tmp/parrot-archive-keyring.deb
    rm -f /tmp/parrot-archive-keyring.deb
    
    run "Copying sources.list" cp "$SCRIPT_DIR/config/system/etc/apt/sources.list" /etc/apt/sources.list
    run "Copying sources.list.d files" cp -rv "$SCRIPT_DIR"/config/system/etc/apt/sources.list.d/* /etc/apt/sources.list.d/
    run "Copying listchanges.conf" cp "$SCRIPT_DIR/config/system/etc/apt/listchanges.conf" /etc/apt/listchanges.conf
    run "Copying os-release" cp "$SCRIPT_DIR/config/system/etc/os-release" /etc/os-release

    # Install Core Edition packages from Parrot repos
    run "Updating package lists" apt update
    run "Upgrading system packages" apt upgrade -y
    if [ "$(uname -m)" == "aarch64" ]; then
        run "Blacklisting incompatible packages" apt-mark hold broadcom-sta-dkms
    fi
    install_packages "${core_packages[@]}"

    echo "[!] Core Edition packages installation completed successfully."
}