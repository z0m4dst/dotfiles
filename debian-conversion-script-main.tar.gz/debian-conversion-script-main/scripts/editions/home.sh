#!/bin/bash

set -euo pipefail

source "$SCRIPT_DIR/scripts/install_packages.sh"

home() {
    local home_packages
    mapfile -t home_packages < "$SCRIPT_DIR/config/packages/home.txt"

    install_packages "${home_packages[@]}"
    echo "[!] Home Edition packages installation completed successfully."
}
