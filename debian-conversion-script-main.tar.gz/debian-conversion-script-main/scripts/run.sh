#!/bin/bash

set -euo pipefail

source "$SCRIPT_DIR/scripts/handle_error.sh"

run() {
    local desc="$1"
    shift
    echo "Executing: $desc"
    if ! "$@"; then
        handle_error "Command failed: $desc"
    fi
}
